<?php

require_once ("db.php");


if(isset($_POST['accion'])){ 
    switch($_POST['accion']){

        case 'editar_propietario':
            editar_propietario();
        break;

        case 'eliminar_propietario':
            eliminar_propietario();
        break;
       
        case 'agregar_propietario':
            agregar_propietario();
        break;

        case 'editar_panteon_municipal':
            editar_panteon_municipal();
        break;

        case 'eliminar_panteon_municipal':
            eliminar_panteon_municipal();
        break;

        case 'agregar_panteon_municipal':
            agregar_panteon_municipal();
        break;

        case 'editar_panteon_jardin':
            editar_panteon_jardin();
        break;

        case 'eliminar_panteon_jardin':
            eliminar_panteon_jardin();
        break;

        case 'agregar_panteon_jardin':
            agregar_panteon_jardin();
        break;

        case 'editar_servicios':
            editar_servicios();
        break;

        case 'eliminar_servicios':
            eliminar_servicios();
        break;

        case 'agregar_servicios':
            agregar_servicios();
        break;

        case 'editar_difuntos':
            editar_difuntos();
        break;

        case 'eliminar_difuntos':
            eliminar_difuntos();
        break;

        case 'agregar_difuntos':
            agregar_difuntos();
        break;
    }

}

function agregar_propietario(){

    global $conexion;
    extract($_POST);


    $consulta="INSERT INTO propietario (nombre_completo,sexo,fecha_nacimiento,edad,curp,celular,foto,correo,comprobante_domicilio)
    VALUES ('$nombre_completo','$sexo', '$fecha_nacimiento', '$edad', '$curp', '$celular', '$foto', '$correo', '$comprobante_domicilio');" ;

    mysqli_query($conexion, $consulta);
    
    header("Location: ../view/index.php");
}


function editar_propietario(){

    global $conexion;
    extract($_POST);
                
    $consulta="UPDATE propietario SET nombre_completo = '$nombre_completo', sexo = '$sexo', fecha_nacimiento = '$fecha_nacimiento', edad = '$edad', curp ='$curp', celular = '$celular', foto = '$foto', correo = '$correo', comprobante_domicilio = '$comprobante_domicilio' WHERE id_propietario = $id_propietario";

    mysqli_query($conexion, $consulta);
    header("Location: ../view/index.php");
}


function eliminar_propietario(){

    global $conexion;
    extract($_POST);
    $id = $_POST['id_propietario'];
    $consulta = "DELETE FROM `propietario` WHERE `id_propietario` = $id_propietario";
    mysqli_query($conexion, $consulta);
    header("Location: ../view/index.php");
}

function agregar_panteon_municipal(){

    global $conexion;
    extract($_POST);


    $consulta="INSERT INTO sepulcro_panteon_municipal (id_propietario,id_difunto,tipo_pago,observacion)
    VALUES ('$id_propietario','$id_difunto', '$tipo_pago', '$observacion');" ;

    mysqli_query($conexion, $consulta);
    
    header("Location: ../view/difuntos.php");
}

function editar_panteon_municipal(){

    global $conexion;
    extract($_POST);
                
    $consulta="UPDATE sepulcro_panteon_municipal SET tipo_pago = '$tipo_pago', observacion = '$observacion' WHERE id_sepulcro_panteon_municipal = $id_sepulcro_panteon_municipal";

    mysqli_query($conexion, $consulta);
    header("Location: ../view/difuntos.php");
}

function eliminar_panteon_municipal(){

    global $conexion;
    extract($_POST);
    $id = $_POST['id_sepulcro_panteon_municipal'];
    $consulta = "DELETE FROM `sepulcro_panteon_municipal` WHERE `id_sepulcro_panteon_municipal` = $id_sepulcro_panteon_municipal";
    mysqli_query($conexion, $consulta);
    header("Location: ../view/difuntos.php");
}

function agregar_panteon_jardin(){

    global $conexion;
    extract($_POST);


    $consulta="INSERT INTO sepulcro_panteon_jardin (id_propietario,id_difunto,tipo_pago,calle,etapa,letra,lote,observacion)
    VALUES ('$id_propietario','$id_difunto', '$tipo_pago', '$calle', '$etapa', '$letra', '$lote', '$observacion');" ;

    mysqli_query($conexion, $consulta);
    
    header("Location: ../view/PanteonJardin.php");
}

function editar_panteon_jardin(){

    global $conexion;
    extract($_POST);
                
    $consulta="UPDATE sepulcro_panteon_jardin SET tipo_pago = '$tipo_pago', calle = '$calle', etapa = '$etapa', letra = '$letra', lote = '$lote', observacion = '$observacion'  WHERE id_sepulcro_panteon_jardin = $id_sepulcro_panteon_jardin";

    mysqli_query($conexion, $consulta);
    header("Location: ../view/PanteonJardin.php");
}

function eliminar_panteon_jardin(){

    global $conexion;
    extract($_POST);
    $id = $_POST['id_sepulcro_panteon_jardin'];
    $consulta = "DELETE FROM `sepulcro_panteon_jardin` WHERE `id_sepulcro_panteon_jardin` = $id_sepulcro_panteon_jardin";
    mysqli_query($conexion, $consulta);
    header("Location: ../view/PanteonJardin.php");
}

function agregar_servicios(){

    global $conexion;
    extract($_POST);


    $consulta="INSERT INTO servicios (id_propietario,id_sepulcro_panteon_municipal,id_tipo_servicio,boleta,mes,fecha,panteon,datos_complementarios)
    VALUES ('$id_propietario','$id_sepulcro_panteon_municipal', '$id_tipo_servicio', '$boleta', '$mes', '$fecha', '$panteon', '$datos_complementarios');" ;

    mysqli_query($conexion, $consulta);
    
    header("Location: ../view/Servicios.php");
}

function editar_servicios(){

    global $conexion;
    extract($_POST);
                
    $consulta="UPDATE servicios SET boleta = '$boleta', mes = '$mes', fecha = '$fecha', panteon = '$panteon', datos_complementarios = '$datos_complementarios' WHERE id_servicios = $id_servicios";

    mysqli_query($conexion, $consulta);
    header("Location: ../view/Servicios.php");
}

function eliminar_servicios(){

    global $conexion;
    extract($_POST);
    $id = $_POST['id_servicios'];
    $consulta = "DELETE FROM `servicios` WHERE `id_servicios` = $id_servicios";
    mysqli_query($conexion, $consulta);
    header("Location: ../view/Servicios.php");
}

function agregar_difuntos(){

    global $conexion;
    extract($_POST);


    $consulta="INSERT INTO difuntos (nombre,sexo,fecha)
    VALUES ('$nombre','$sexo', '$fecha');" ;

    mysqli_query($conexion, $consulta);
    
    header("Location: ../view/Datos_Difuntos.php");
}

function editar_difuntos(){

    global $conexion;
    extract($_POST);
                
    $consulta="UPDATE difuntos SET nombre = '$nombre', sexo = '$sexo', fecha = '$fecha'WHERE id_difuntos = $id_difuntos";

    mysqli_query($conexion, $consulta);
    header("Location: ../view/Datos_Difuntos.php");
}

function eliminar_difuntos(){

    global $conexion;
    extract($_POST);
    $id = $_POST['id_difuntos'];
    $consulta = "DELETE FROM `difuntos` WHERE `id_difuntos` = $id_difuntos";
    mysqli_query($conexion, $consulta);
    header("Location: ../view/Datos_Difuntos.php");
}