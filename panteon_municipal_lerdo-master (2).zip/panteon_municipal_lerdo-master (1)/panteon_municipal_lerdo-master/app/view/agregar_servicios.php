<?php require '../../app/model/db.php' ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Registro de Servicios</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>

    <style>
    body {
        background-image: url('../../public/img/FotoPanteon10.jpg');
        background-size: cover;
        background-repeat: no-repeat;
    }

    .card {
        background-color: rgba(255, 255, 255, 0);
        /* Fondo blanco semi-transparente para la tarjeta */
    }

    /* Resto de tu código CSS */
    </style>

    <div class="container mt-5">
        <div class="card">
            <div class="card-header bg-danger text-white">
                <h3 class="text-center">Registro de los Servicios</h3>
            </div>
            <div class="card-body">
                <form action="../../app/model/functions_db.php" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <!-- Columna 1: Datos Personales Parte 1 -->
                        <div class="col-md-4">

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="id_propietario">Id propietario:</label>
                                <input type="text" class="form-control" id="id_propietario" name="id_propietario"
                                    required>
                            </div>

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="id_sepulcro_panteon_municipal">Id Sepulcro Panteon Municipal:</label>
                                <input type="text" class="form-control" id="id_sepulcro_panteon_municipal" name="id_sepulcro_panteon_municipal" required>
                            </div>

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="id_tipo_servicio">Id Tipo Servicio:</label>
                                <input type="text" class="form-control" id="id_tipo_servicio" name="id_tipo_servicio" required>
                            </div>
                            </div>

                            <div class="col-md-4">

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="boleta">Boleta:</label>
                                <input type="text" class="form-control" id="boleta" name="boleta" required>
                            </div>

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="mes">Mes:</label>
                                <input type="text" class="form-control" id="mes" name="mes"
                                    required>
                            </div>

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="fecha">Fecha del Servicio:</label>
                                <input type="date" class="form-control" id="fecha" name="fecha" required>
                            </div>
                        </div>

                        <div class="col-md-4">

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="panteon">Panteon:</label>
                                <input type="text" class="form-control" id="panteon" name="panteon" required>
                            </div>

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="datos_complementarios">Datos Complementarios:</label>
                                <input type="text" class="form-control" id="datos_complementarios" name="datos_complementarios" required>
                            </div>
                        </div>

                        </div>
                    </div>
            </div>

            <div class="fixed-bottom mb-3 text-center">
                <input type="hidden" name="accion" value="agregar_servicios">
                <button type="submit" class="btn btn-success">Guardar</button>
                <button class="btn btn-danger" style="text-decoration: none; color: white;">
                    <a href="Servicios.php" style="color: white;">Cancelar</a>
                </button>

            </div>
            </form>
        </div>
    </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>