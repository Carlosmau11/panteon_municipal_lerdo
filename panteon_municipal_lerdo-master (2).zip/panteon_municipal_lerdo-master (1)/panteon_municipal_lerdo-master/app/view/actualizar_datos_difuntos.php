<?php

$id = $_GET['id_difuntos'];
require_once ("../../app/model/db.php");
$consulta = "SELECT * FROM difuntos WHERE id_difuntos = $id";
$resultado = mysqli_query($conexion, $consulta);
$difuntos = mysqli_fetch_assoc($resultado);

?>
<?php require '../../app/model/db.php' ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Actualizar Datos de los Difuntos</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>

    <style>
    body {
        background-image: url('../../public/img/FotoPanteon10.jpg');
        background-size: cover;
        background-repeat: no-repeat;
    }

    .card {
        background-color: rgba(255, 255, 255, 0);
        /* Fondo blanco semi-transparente para la tarjeta */
    }

    /* Resto de tu código CSS */
    </style>

    <div class="container mt-5">
        <div class="card">
            <div class="card-header bg-danger text-white">
                <h3 class="text-center">Actualizar Registro de Difuntos</h3>
            </div>
            <div class="card-body">
                <form action="../../app/model/functions_Db.php" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <!-- Columna 1: Datos Personales Parte 1 -->

                        <div class="col-md-3">

                            </div>
                        <!-- Columna 2: Datos Personales Parte 2 -->

                        <div class="col-md-3">

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="id_difuntos">Id Difuntos:</label>
                                <input type="text" class="form-control" id="id_difuntos"
                                    name="id_difuntos"
                                    value="<?php echo $difuntos ['id_difuntos']; ?>"
                                    required>
                            </div>

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="nombre">Nombre:</label>
                                <input type="text" class="form-control" id="nombre" name="nombre"
                                    value="<?php echo $difuntos ['nombre']; ?>" required>
                            </div>
                            </div>

                            <!-- Columna 3: Datos Personales Parte 3 -->

                            <div class="col-md-3">

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="sexo">Sexo:</label>
                                <input type="text" class="form-control" id="sexo" name="sexo"
                                    value="<?php echo $difuntos ['sexo']; ?>" required>
                            </div>

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="fecha">Fecha:</label>
                                <input type="date" class="form-control" id="fecha" name="fecha"
                                    value="<?php echo $difuntos ['fecha']; ?>" required>
                            </div>
                            </div>

                            <div class="col-md-3">

                        </div>
                    </div>
            </div>

            <div class="fixed-bottom mb-3 text-center">
                <input type="hidden" name="accion" value="editar_difuntos">
                <input type="hidden" name="id_difuntos"
                    value="<?php echo $_GET['id_difuntos']; ?>">
                <button type="submit" class="btn btn-success">Guardar</button>
                <button class="btn btn-danger" style="text-decoration: none; color: white;">
                    <a href="Datos_Difuntos.php" style="color: white;">Cancelar</a>
                </button>
            </div>
            </form>
        </div>
    </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>