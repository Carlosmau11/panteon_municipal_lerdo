<?php require '../../app/model/db.php' ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Registro en el panteon Municipal</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>

    <style>
    body {
        background-image: url('../../public/img/FotoPanteon10.jpg');
        background-size: cover;
        background-repeat: no-repeat;
    }

    .card {
        background-color: rgba(255, 255, 255, 0);
        /* Fondo blanco semi-transparente para la tarjeta */
    }

    /* Resto de tu código CSS */
    </style>

    <div class="container mt-5">
        <div class="card">
            <div class="card-header bg-danger text-white">
                <h3 class="text-center">Registro en el panteon Municipal</h3>
            </div>
            <div class="card-body">
                <form action="../../app/model/functions_db.php" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-3">
                            <!-- Columna 1: Puedes agregar más campos aquí si es necesario -->
                        </div>
                        
                        <div class="col-md-3">
                            <!-- Columna 2: Puedes agregar más campos aquí si es necesario -->

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="id_propietario">Id propietario:</label>
                                <input type="text" class="form-control" id="id_propietario" name="id_propietario"
                                    required>
                            </div>

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="id_difunto">Id Difunto:</label>
                                <input type="text" class="form-control" id="id_difunto" name="id_difunto" required>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <!-- Columna 3: Puedes agregar más campos aquí si es necesario -->
                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="tipo_pago">Tipo de Pago:</label>
                                <input type="text" class="form-control" id="tipo_pago" name="tipo_pago" required>
                            </div>

                            <div class="form-group">
                                <label style="color: rgb(231, 223, 223);" for="observacion">Observaciones:</label>
                                <input type="text" class="form-control" id="observacion" name="observacion" required>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <!-- Columna 4: Puedes agregar más campos aquí si es necesario -->
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="fixed-bottom mb-3 text-center">
        <form action="../../app/model/functions_db.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="accion" value="agregar_panteon_municipal">
            <button type="submit" class="btn btn-success">Guardar</button>
            <a href="difuntos.php" class="btn btn-danger" style="text-decoration: none; color: white;">Cancelar</a>
        </form>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>