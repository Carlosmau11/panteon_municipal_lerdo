// demo/datatables-demo.js
$(document).ready(function() {
  $('#dataTable').DataTable({
      "lengthMenu": [[5, 10, -1], [5, 10, "Todos"]],
      "pageLength": 5, // Establecer el valor por defecto en 5
      "language": {
          "search": "Buscar:",
          "lengthMenu": "Mostrar _MENU_ entradas por página",
          "info": "Mostrando _START_ a _END_ de _TOTAL_ entradas",
          "infoEmpty": "Mostrando 0 a 0 de 0 entradas", // Mensaje cuando no hay entradas
          "infoFiltered": "(filtrado de _MAX_ entradas en total)",
          "zeroRecords": "No se encontraron entradas",
          "paginate": {
              "first": "Primero",
              "previous": "Anterior",
              "next": "Siguiente",
              "last": "Último"
          }
      },
      // ... otras configuraciones
  });
});
